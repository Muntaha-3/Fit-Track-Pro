from flask import Blueprint, render_template, redirect, url_for, session

dashboard_bp = Blueprint("dashboard_bp", __name__)

@dashboard_bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@dashboard_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("dashboard_bp.dashboard"))

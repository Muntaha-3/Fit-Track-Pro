from flask import Flask

from bmi_routes import bmi_bp
from dashboard_routes import dashboard_bp 
from calorie_routes import calorie_bp
from exercise_routes import exercise_bp
from meal_planner_routes import meal_planner_bp
from water_intakes_routes import water_intakes_bp
from main_routes import main_bp
from auth_routes import auth_bp

app = Flask(__name__)
app.secret_key = "secret123"

app.register_blueprint(dashboard_bp)
app.register_blueprint(bmi_bp)
app.register_blueprint(calorie_bp)
app.register_blueprint(exercise_bp)
app.register_blueprint(meal_planner_bp)
app.register_blueprint(water_intakes_bp)
app.register_blueprint(main_bp)
app.register_blueprint(auth_bp)

if __name__ == "__main__":
    app.run(debug=True)

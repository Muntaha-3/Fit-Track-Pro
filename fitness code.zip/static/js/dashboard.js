document.addEventListener("DOMContentLoaded", function () {
  console.log("Dashboard Loaded");

  const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const lastBMI = localStorage.getItem("latestBMI") || 22.5;

  const bmiCtx = document.getElementById("bmiChart");
  let bmiChart;

  if (bmiCtx) {
    bmiChart = new Chart(bmiCtx, {
      type: "line",
      data: {
        labels: labels,
        datasets: [
          {
            label: "BMI Progress",
            data: [22, 22.2, 22.1, 22.3, 22.5, 22.4, parseFloat(lastBMI)],
            borderWidth: 2,
            tension: 0.3,
            fill: true,
          },
        ],
      },
    });
  }

  const submitBtn = document.querySelector(".submit-btn");

  if (submitBtn) {
    submitBtn.addEventListener("click", function () {
      const weight = document.getElementById("weight").value;
      const height = document.getElementById("height").value;

      if (weight > 0 && height > 0) {
        const bmi = (weight / (height / 100) ** 2).toFixed(1);
        alert("Your BMI is: " + bmi);
        localStorage.setItem("latestBMI", bmi);

        if (bmiChart) {
          bmiChart.data.datasets[0].data[6] = parseFloat(bmi);
          bmiChart.update();
        }
      } else {
        alert("Enter valid values");
      }
    });
  }
});

import pandas as pd
import os
from datetime import datetime

def save_bmi_to_excel(data, filename="db/bmi_data.xlsx"):
    """
    Save BMI data to Excel. If file exists, append; otherwise create new.
    
    data: dict
        Example: {"Date": "2025-12-27 22:30", "Gender": "Male", "Weight": 70, "Height": 175, "BMI": 22.5, "Status": "Normal"}
    """
    if os.path.exists(filename):
        df = pd.read_excel(filename)
        df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
    else:
        df = pd.DataFrame([data])

    df.to_excel(filename, index=False)
    

#Calories
# ================= CALORIES =================
def save_calories_to_excel(data, filename="db/calorie_data.xlsx"):
    if os.path.exists(filename):
        df = pd.read_excel(filename)
        df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
    else:
        df = pd.DataFrame([data])

    df.to_excel(filename, index=False)


##############exercise###############

def save_exercise_to_excel(data, filename="db/exercise_data.xlsx"):
    # Auto-create db folder if it does not exist
    os.makedirs("db", exist_ok=True)

    if os.path.exists(filename):
        df = pd.read_excel(filename)
        df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
    else:
        df = pd.DataFrame([data])

    df.to_excel(filename, index=False)


#################meal###################

def save_meal_to_excel(data, filename="db/meal_plans.xlsx"):
    # Ensure db folder exists
    os.makedirs("db", exist_ok=True)

    if os.path.exists(filename):
        df = pd.read_excel(filename)
        df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
    else:
        df = pd.DataFrame([data])

    df.to_excel(filename, index=False) 



